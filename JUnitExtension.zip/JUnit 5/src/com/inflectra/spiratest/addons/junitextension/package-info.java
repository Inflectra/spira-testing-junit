/**
 * Contains the core functionality for the SpiraTest extension for JUnit
 *
 * @since 1.2
 */
package com.inflectra.spiratest.addons.junitextension;
