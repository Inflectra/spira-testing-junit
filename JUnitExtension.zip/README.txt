JUnit Extension for SpiraTest
===== ========= === =========

The latest documentation for using this extension
can be found at http://www.inflectra.com/SpiraTest/Documentation.aspx

The PDF guide contains details instructions for integrating SpiraTest or SpiraTeam
with a variety of automated testing tools including JUnit.

(C) Copyright 2006-2012 Inflectra Corporation.
